//
//  ViewController.m
//  DYDemoTools
//
//  Created by 李云新 on 2019/8/20.
//  Copyright © 2019年 Lambert. All rights reserved.
//

#import "ViewController.h"
#import "KHBarButton.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.rightBarButtonItem = [[KHBarButton rightBtnWithTitle:@"德玛西亚" Color:[UIColor blackColor] ClickOption:^{
        NSLog(@"德玛西亚，永世长存");
    }] getBarItem];
}

@end
