//
//  DYDemoTools.h
//  DYDemoTools
//
//  Created by 李云新 on 2019/8/20.
//

#import <Foundation/Foundation.h>

@interface DYDemoTools : NSObject

///获取KHealthTools这个Bundle的图片
+ (UIImage *)getToolsBundleImage:(NSString *)imageName;

@end

