//
//  main.m
//  DYDemoTools
//
//  Created by 李云新 on 2019/8/20.
//  Copyright © 2019年 Lambert. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
